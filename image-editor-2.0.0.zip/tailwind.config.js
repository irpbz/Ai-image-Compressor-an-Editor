/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ['./*.html', './dist/scripts/*.js'],
  theme: {
    extend: {},
  },
  plugins: [],
}